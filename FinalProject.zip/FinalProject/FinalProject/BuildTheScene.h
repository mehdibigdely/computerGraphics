#pragma once
#include "BuildShapes.h"
#include "Meshes.h"

class SceneBuilder
{
public:
	static void UBuildScene(vector<GLMesh>& scene);
};
