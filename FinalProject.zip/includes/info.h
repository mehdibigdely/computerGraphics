#pragma once
// used to separate the user info display/output (control keys availability to use)
class info 
{
public:
	static void printUserGuide();
};

